import 'package:f1_calendar/app/theme.dart';
import 'package:f1_calendar/core/utils/date_x.dart';
import 'package:f1_calendar/features/calendar/domain/race.dart';
import 'package:f1_calendar/features/calendar/presentation/next_race_card.dart';
import 'package:f1_calendar/shared/models/locale_labels.dart';
import 'package:f1_calendar/shared/models/team_asset.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';

Race buildRace({
  String round = '21',
  String raceName = 'Las Vegas Grand Prix',
  String date = '2026-11-22',
  String? time = '04:00:00Z',
  String locality = 'Las Vegas',
  String country = 'USA',
  bool sprint = false,
}) {
  return Race(
    season: '2026',
    round: round,
    raceName: raceName,
    circuit: Circuit(
      circuitId: 'vegas',
      circuitName: 'Las Vegas Strip Street Circuit',
      location: CircuitLocation(
        lat: '36.1147',
        long: '-115.173',
        locality: locality,
        country: country,
      ),
    ),
    date: date,
    time: time,
    sprint: sprint ? const RaceSession(date: '2026-11-21', time: '04:00:00Z') : null,
  );
}

void main() {
  setUpAll(() async {
    Intl.defaultLocale = 'zh_CN';
    await initializeDateFormatting('zh_CN');
  });

  group('下一场比赛计算', () {
    test('取最近一场尚未开始的比赛', () {
      final races = <Race>[
        buildRace(round: '20', date: '2026-11-08', locality: 'São Paulo', country: 'Brazil'),
        buildRace(),
        buildRace(round: '22', date: '2026-11-29', locality: 'Lusail', country: 'Qatar'),
      ];
      final next = nextRaceOf(races, DateTime(2026, 11, 11, 22));
      expect(next, isNotNull);
      expect(next!.round, '21');
    });

    test('整季结束后返回 null', () {
      final races = <Race>[buildRace()];
      final next = nextRaceOf(races, DateTime(2026, 12, 30));
      expect(next, isNull);
    });

    test('已开赛的分站计为已完赛', () {
      final race = buildRace();
      expect(race.isFinishedAt(DateTime(2026, 12, 1)), isTrue);
      expect(race.isFinishedAt(DateTime(2026, 11, 1)), isFalse);
    });

    test('倒计时按天/时/分拆解，负值归零', () {
      final race = buildRace();
      final start = race.startsAtLocal!;
      final parts = CountdownParts.fromDuration(start.difference(start.subtract(const Duration(days: 2, hours: 3, minutes: 5))));
      expect(parts.days, 2);
      expect(parts.hours, 3);
      expect(parts.minutes, 5);

      final past = CountdownParts.fromDuration(
        start.difference(start.add(const Duration(hours: 1))),
      );
      expect(past.days, 0);
      expect(past.hours, 0);
    });

    test('赛历按自然月分组且保持站次顺序', () {
      final races = <Race>[
        buildRace(round: '1', date: '2026-03-08', locality: 'Melbourne', country: 'Australia'),
        buildRace(round: '2', date: '2026-03-15', locality: 'Shanghai', country: 'China'),
        buildRace(),
      ];
      final grouped = groupByMonth(races);
      expect(grouped.keys.toList(), <String>['3月', '11月']);
      expect(grouped['3月']!.map((race) => race.round).toList(), <String>['1', '2']);
    });

    test('不硬编码站数：列表长度随接口返回', () {
      final races = <Race>[buildRace(round: '1'), buildRace(round: '2')];
      expect(races.length, 2);
      expect(races.last.roundNumber, 2);
    });
  });

  group('素材映射与文案', () {
    test('11 支车队都有车图与两名车手', () {
      expect(teamAssets, hasLength(11));
      for (final team in teamAssets) {
        expect(team.carUrlList, contains('w_600'));
        expect(team.carUrlDetail, contains('w_1200'));
        expect(team.drivers, hasLength(2));
        expect(team.drivers.first.avatarUrl(slug: team.slug), contains('w_440'));
      }
    });

    test('未知车队走灰色兜底而不是抛错', () {
      final unknown = teamAssetFor('unknown_team');
      expect(unknown.color, const Color(0xFF9E9E9E));
      expect(unknown.drivers, isEmpty);
    });

    test('美国站用城市区分三个分站', () {
      expect(raceTitleZh(buildRace()), '拉斯维加斯大奖赛');
      expect(
        raceTitleZh(buildRace(locality: 'Miami', country: 'USA')),
        '迈阿密大奖赛',
      );
      expect(
        raceTitleZh(buildRace(locality: 'Melbourne', country: 'Australia')),
        '澳大利亚大奖赛',
      );
    });

    test('赛道长名压成短名', () {
      expect(
        shortCircuitName('Albert Park Grand Prix Circuit'),
        'Albert Park',
      );
      expect(
        shortCircuitName('Las Vegas Strip Street Circuit'),
        'Las Vegas Strip',
      );
    });

    test('深色模式渐变整体压暗', () {
      final light = raceGradient(buildRace(), dark: false).first;
      final dark = raceGradient(buildRace(), dark: true).first;
      expect(light.computeLuminance(), greaterThan(dark.computeLuminance()));
    });
  });

  testWidgets('下一场卡片展示分站、赛道与倒计时', (tester) async {
    final race = buildRace();
    await tester.pumpWidget(
      MaterialApp(
        theme: buildAppTheme(Brightness.light),
        home: Scaffold(
          body: SingleChildScrollView(
            child: NextRaceCard(race: race, now: DateTime(2026, 11, 20, 12)),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('下一场'), findsOneWidget);
    expect(find.text('拉斯维加斯大奖赛'), findsOneWidget);
    expect(find.text('ROUND 21'), findsOneWidget);
    expect(find.text('天'), findsOneWidget);
    expect(find.text('时'), findsOneWidget);
    expect(find.text('分'), findsOneWidget);
  });
}