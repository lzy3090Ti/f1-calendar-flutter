import '../domain/race.dart';

/// 赛历接口响应包装：`MRData.RaceTable.Races`。
///
/// 纯传输对象，手写解析以避免生成器对嵌套列表字段的额外约束。
class RaceTableResponse {
  const RaceTableResponse({required this.mrData});

  final RaceMrData mrData;

  factory RaceTableResponse.fromJson(Map<String, dynamic> json) {
    final mrData = json['MRData'];
    return RaceTableResponse(
      mrData: mrData is Map<String, dynamic>
          ? RaceMrData.fromJson(mrData)
          : const RaceMrData(races: <Race>[], season: ''),
    );
  }
}

class RaceMrData {
  const RaceMrData({required this.races, required this.season});

  final List<Race> races;
  final String season;

  factory RaceMrData.fromJson(Map<String, dynamic> json) {
    final table = json['RaceTable'];
    if (table is! Map<String, dynamic>) {
      return const RaceMrData(races: <Race>[], season: '');
    }
    final rawRaces = table['Races'];
    final races = rawRaces is List
        ? rawRaces
            .whereType<Map<String, dynamic>>()
            .map(Race.fromJson)
            .toList(growable: false)
        : const <Race>[];
    return RaceMrData(
      races: races,
      season: table['season'] as String? ?? '',
    );
  }
}